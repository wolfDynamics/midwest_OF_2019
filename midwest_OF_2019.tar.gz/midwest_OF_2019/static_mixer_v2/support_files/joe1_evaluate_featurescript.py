'''
Evaluate feature script
===

You should give the following information:

	- did (str): Document ID
	- wid (str): Workspace ID
	- eid (str): Element ID
	- body_feature: dict with the body of the feature to update

'''


from apikey.client import Client

# stacks to choose from
stacks = {
    'cad': 'https://cad.onshape.com'
}

# create instance of the onshape client; change key to test on another stack
c = Client(stack=stacks['cad'], logging=True)



# get features for doc
#did = raw_input('Enter document ID: ')
#wid = raw_input('Enter workspace ID: ')
#eid = raw_input('Enter element ID: ')



did = '905b0c72c34976f45db62a5c'
wid = '642caf6241a7b2af8a598ec3'
eid = 'e85001919ad32b850c07a142'



#In body_feature you can add the featureScript to evaluate
#In this case is evaluating the information saved in the Part Studio variable "#face_area"
#
#The custom featureScript "Measure value" was used to compute the volume of the part
#More custom featureScript in https://www.onshape.com/features/custom-features
#
#The info evaluated by the custom featureSript is saved in the Part Studio variable "#nameOfVariable".
#Then, you can simply retrieve that variable as follows

body_feature = 	{  
  		#"script" : 
  		#"function(context, queries) {return getVariable(context, 'face_area');}"
  		"script" : 
  		"function(context, queries) {return getVariable(context, 'vol2');}"
		}



out = c.featurescript(did, wid, eid, body_feature)


#Write the feature output in the file feature.json
file = open('featurescript_output.json', 'w')
file.write(out.text)
file.close()
