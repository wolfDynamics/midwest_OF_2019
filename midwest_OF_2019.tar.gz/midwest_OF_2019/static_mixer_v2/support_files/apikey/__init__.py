'''
apikey
======

Demonstrates usage of API keys for the Onshape REST API
'''

__copyright__ = 'Copyright (c) 2016 Onshape, Inc.'
__license__ = 'All rights reserved.'
__title__ = 'apikey'
__all__ = ['onshape', 'client', 'utils']
