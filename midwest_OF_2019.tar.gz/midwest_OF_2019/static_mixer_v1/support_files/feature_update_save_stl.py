'''
Feature update - Export STL - dd small delay to avoid repeting saved STL

You should give the following information:

	- did (str): Document ID
	- wid (str): Workspace ID
	- eid (str): Element ID
	- fid (str): Feature ID
	- body_feature: dict with the body of the feature to update

'''


from apikey.client import Client



# stacks to choose from
stacks = {
    'cad': 'https://cad.onshape.com'
}

# create instance of the onshape client; change key to test on another stack
c = Client(stack=stacks['cad'], logging=True)

did = '059c39d585ecdf70cd04c572'
wid = '3712935208dc82f29c883aaa'
eid = '15bba0fef531418dd376d5e3'

#Feature id
fid = "FigN1lrYOV7vOz5_1"

#Read input file with body of the feature
body_feature = open("feature_to_update.json", "r")

#print body_feature.read()


# update FEATURES and pass body of feature
out = c.feature_update(did, wid, eid, fid, body_feature)

#To save details
file = open('updated_output.txt', 'w')
file.write(out.text)
file.close()



# get the STL export
stl = c.part_studio_stl(did, wid, eid)
file = open('output.stl', 'w')
file.write(stl.text)
file.close()



